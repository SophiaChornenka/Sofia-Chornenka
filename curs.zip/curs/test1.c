#include <stdio.h>
#include <stdlib.h>

int main() 
{
int _cCCCCCCCC;
int _bBBBBBBBB;
int _aAAAAAAAA;
printf("Enter _aAAAAAAAA: ");
scanf("%d", &_aAAAAAAAA);
printf("Enter _bBBBBBBBB: ");
scanf("%d", &_bBBBBBBBB);
printf("Enter _cCCCCCCCC: ");
scanf("%d", &_cCCCCCCCC);
if ((_aAAAAAAAA > _bBBBBBBBB)) if ((_aAAAAAAAA > _cCCCCCCCC)) goto abig;
else printf("%d\n", _cCCCCCCCC);
goto outer;
abig:
printf("%d\n", _aAAAAAAAA);
goto outer;
if ((_bBBBBBBBB < _cCCCCCCCC)) printf("%d\n", _cCCCCCCCC);
else printf("%d\n", _bBBBBBBBB);
outer:
if (((_aAAAAAAAA == _bBBBBBBBB) && ((_aAAAAAAAA == _cCCCCCCCC) && (_aAAAAAAAA == _cCCCCCCCC)))) printf("%d\n", 1);
else printf("%d\n", 0);
if (((_aAAAAAAAA < 0) || ((_bBBBBBBBB < 0) || (_cCCCCCCCC < 0)))) printf("%d\n", -1);
else printf("%d\n", 0);
if (!((_aAAAAAAAA < (_bBBBBBBBB + _cCCCCCCCC)))) printf("%d\n", 10);
else printf("%d\n", 0);
   system("pause");
    return 0;
}
