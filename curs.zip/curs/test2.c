#include <stdio.h>
#include <stdlib.h>

int main() 
{
int _jJJJJJJJJ;
int _iIIIIIIII;
int _xXXXXXXXX;
int _bBBBBBBBB;
int _aAAAAAAAA;
printf("Enter _aAAAAAAAA: ");
scanf("%d", &_aAAAAAAAA);
printf("Enter _bBBBBBBBB: ");
scanf("%d", &_bBBBBBBBB);
for(
_xXXXXXXXX = _aAAAAAAAA;
_xXXXXXXXX <= _bBBBBBBBB;
++_xXXXXXXXX
) printf("%d\n", (_xXXXXXXXX * _xXXXXXXXX));
_xXXXXXXXX = 0;
for(
_iIIIIIIII = 1;
_iIIIIIIII <= _aAAAAAAAA;
++_iIIIIIIII
) for(
_jJJJJJJJJ = 1;
_jJJJJJJJJ <= _bBBBBBBBB;
++_jJJJJJJJJ
) _xXXXXXXXX = (_xXXXXXXXX + 1);
printf("%d\n", _xXXXXXXXX);
   system("pause");
    return 0;
}
